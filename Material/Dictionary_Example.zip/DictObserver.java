public interface DictObserver
{
  public void update(DictionaryInterface theDictionary);
}
