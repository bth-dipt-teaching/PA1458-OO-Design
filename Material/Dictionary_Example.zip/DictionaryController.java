import java.util.*;

public class DictionaryController implements ControllerInterface
{
  private DictionaryInterface myDictionary;
  private Vector<OutputInterface> myOutputs=new Vector<OutputInterface>();
  
  public DictionaryController(DictionaryInterface theDictionary, OutputInterface theView) {
    myDictionary=theDictionary;
    myOutputs.addElement(theView);
  }

  public void addOutput(OutputInterface theView) {
    myOutputs.addElement(theView);
  }
  
  public void search(String theWord) {
    DictionaryInterface.DictWord d=myDictionary.getWord(theWord);

    Enumeration<OutputInterface> e=myOutputs.elements();
    while(e.hasMoreElements()) {
      OutputInterface out= e.nextElement();
      out.display(d.theWord, d.theExpl);
    }
  }
  
  public void add(String theWord, String theExp) {
    // Do sanity checks and stuff on the word and explanation first
    // Then, if it is still ok, add the word to the dictionary
    myDictionary.addWord(theWord, theExp);
  }
  
  public void edit(String theWord, String theExp) {
    if (myDictionary.getWord(theWord).theExpl==null) {
      Log.log("Word not found; cannot edit: " + theWord);
    }
    
    // Do sanity checks and stuff on the word and explanation first
    // Then, if it is still ok, edit the word in the dictionary    
    myDictionary.editWord(theWord, theExp);

  }
  
  public void delete(String theWord) {
    if (myDictionary.getWord(theWord).theExpl==null) {
      Log.log("Word not found; cannot remove: " + theWord);
    }
    
    // Do sanity checks and stuff on the word and explanation first
    // Then, if it is still ok, remove the word
    myDictionary.deleteWord(theWord);

  }

}
