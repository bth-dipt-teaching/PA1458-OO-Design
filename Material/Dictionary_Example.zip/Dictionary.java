import java.util.*;
import java.io.*;

public class Dictionary implements DictionaryInterface
{
  private static String DEFAULTFILENAME="dict.txt";
  private String myFileName=DEFAULTFILENAME;
  private Properties myData;
  private FileOutputStream myFile;
  private String lastWord;
  
  public Dictionary() {
    this(DEFAULTFILENAME);
  }

  public Dictionary(String theFileName) {
    myFileName=theFileName;
    myData=new Properties();
    try {
      myData.load(new FileInputStream(myFileName));
      myFile=new FileOutputStream(myFileName);
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void addWord(String theWord, String theExpl) {
    myData.setProperty(theWord, theExpl);
    lastWord=theWord;
    save();
    notify(Action.ADD);
  }

  public void deleteWord(String theWord) {
    myData.remove(theWord);
    lastWord=theWord;
    save();
    notify(Action.REMOVE);    
  }

  public void editWord(String theWord, String theExpl) {
    String oldExpl= (String) myData.setProperty(theWord, theExpl);
    lastWord=theWord;
    save();
    notify(Action.EDIT);
  }

  public DictWord getWord(String theWord) {
    DictWord d=new DictWord();
    d.theWord=theWord;
    d.theExpl=myData.getProperty(theWord);
    lastWord=theWord;
    return d;
  }

  public DictWord getWord() {
    DictWord d=new DictWord();
    d.theWord=lastWord;
    d.theExpl=myData.getProperty(lastWord);
    return d;    
  }
  
  public Vector<DictWord> getWords() {
    Vector<DictWord> myVector=new Vector<DictWord>();
    Enumeration e=myData.propertyNames();

    while (e.hasMoreElements()) {
      String word=(String) e.nextElement();
      String expl=myData.getProperty(word);
      myVector.addElement(new DictWord(word,expl));
    }
    
    return myVector;
  }


  private void save() {
    try {
      myData.store(myFile, "Dictionary");
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }
  
  // ------------------------------
  // Observer Pattern stuff
  // ------------------------------

  private Action myAction=DictionaryInterface.Action.NONE;

  private Vector<DictObserver> myObservers = new Vector<DictObserver>();
  
  private void notify(Action theAction) {
    myAction=theAction;

    Enumeration<DictObserver> e=myObservers.elements();
    while(e.hasMoreElements()) {
      DictObserver d= e.nextElement();
      d.update(this);
    }

    myAction=DictionaryInterface.Action.NONE;
  }

  public DictionaryInterface.Action getAction() {
    return myAction;
  }

  public void addObserver(DictObserver theObserver) {
    myObservers.addElement(theObserver);
  }
}
