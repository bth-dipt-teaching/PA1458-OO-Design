import java.util.logging.*;
import java.io.*;

public class Log
{
  private final static Logger logger=Logger.getLogger("DictionaryLogging");
  private static FileHandler fh=null;

  public static void init(){
    try {
      fh=new FileHandler("dictionary.log", false);
    } catch (IOException e) {
      e.printStackTrace();
    }
    fh.setFormatter(new SimpleFormatter());
    logger.addHandler(fh);
  }

  public static void log(String theLogEntry) {
    logger.info(theLogEntry);
  }
}
