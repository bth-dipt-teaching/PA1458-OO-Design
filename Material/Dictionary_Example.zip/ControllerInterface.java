public interface ControllerInterface
{
  public void addOutput(OutputInterface theView);
  public void search(String theWord);
  public void add(String theWord, String theExp);
  public void edit(String theWord, String theExp);
  public void delete(String theWord);
}
