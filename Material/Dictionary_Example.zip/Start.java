public class Start
{
  public static void debugDict(Dictionary d) {
    d.addWord("AFK", "See BTH");
    d.addWord("Snafu", "See BTH");
    d.addWord("BTH", "See AFK");
  }
  
  
  public static void setup(MainGUI theGUI) {
    // Create Dictionary
    Dictionary theDict = new Dictionary("dict.txt");
    debugDict(theDict); // Make sure there is stuff in it.
    
    // Create Views
    LogView lv=new LogView();
    WordView wv=new WordView();
    WordDefinitionView wdv=new WordDefinitionView();

    // Initialise views where necessary
    wv.getWords(theDict);

    
    // Create and Connect the Controller
    DictionaryController dc=new DictionaryController(theDict, wdv);
    lv.setController(dc);
    wv.setController(dc);
    wdv.setController(dc); // Circular, but ok

    // Add stuff to GUI
    // theGUI.addView(lv) // skip the LogView; it prints to console/file
    theGUI.addView(wv);
    theGUI.addView(wdv);

    // Connect views to dictionary, so that changes are reflected
    theDict.addObserver(lv);
    theDict.addObserver(wv);
    theDict.addObserver(wdv);
  }
  
  public static void main(String [] args) {
    Log.init();
    Log.log("Starting Dictionary Application");
    
    MainGUI g=new MainGUI();    
    setup(g);
    g.start();
  }
}
