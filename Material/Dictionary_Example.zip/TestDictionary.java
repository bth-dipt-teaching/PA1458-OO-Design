import org.junit.Test;
import static org.junit.Assert.*;

public class TestDictionary
{
  Dictionary d=new Dictionary("test.txt");;

  
  @Test
  public void TestAddWord() {
    d.addWord("TestAddWord", "Test Add Explanation");

    DictionaryInterface.DictWord dw=d.getWord("TestAddWord");

    assertEquals("TestAddWord", dw.theWord);
    assertEquals("Test Add Explanation", dw.theExpl);
  }

  @Test
  public void TestGetWord() {
    d.addWord("TestWord", "Test Explanation");
    DictionaryInterface.DictWord dw=d.getWord("TestWord");
    assertEquals("TestWord", dw.theWord);
    assertEquals("Test Explanation", dw.theExpl);
  }

  @Test
  public void TestRemoveWord() {
    DictionaryInterface.DictWord dw=d.getWord("TestRemove");

    if (dw.theExpl==null) {
      // Word does not exist; add it.
      d.addWord("TestRemove", "Test Remove Explanation");
    }
    dw=d.getWord("TestRemove");
    assertNotNull(dw.theExpl);

    d.deleteWord("TestRemove");
    dw=d.getWord("TestRemove");
    assertNull(dw.theExpl);
  }
}
