public interface OutputInterface
{
  public void display(String theWord, String theExpl);
}
