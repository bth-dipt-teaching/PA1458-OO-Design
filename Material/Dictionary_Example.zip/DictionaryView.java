public interface DictionaryView
{
  public void setController(ControllerInterface theController);
}
