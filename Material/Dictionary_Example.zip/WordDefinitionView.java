import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class WordDefinitionView extends JPanel implements DictObserver, OutputInterface, DictionaryView
{
  private JTextField myWord= new JTextField();
  private JTextField myExpl= new JTextField(25);
  private JButton mySearch = new JButton("Search");
  private JButton myAdd = new JButton("Add");
    private JButton myEdit = new JButton("Edit");
  
  public WordDefinitionView() {
    setBorder(BorderFactory.createTitledBorder("Word Definition View"));
    this.setLayout(new BorderLayout());
    JPanel p=new JPanel();
    p.setLayout(new GridLayout(2,2));
    p.add(new JLabel("Word:"));
    p.add(myWord);
    p.add(new JLabel("Explanation"));
    p.add(myExpl);
    this.add("Center",p);

    p=new JPanel();
    p.setLayout(new FlowLayout());
    p.add(mySearch);
    p.add(myAdd);
    p.add(myEdit);
    this.add("South", p);

    mySearch.addActionListener(new SearchButtonListener());
    myAdd.addActionListener(new AddButtonListener());
    myEdit.addActionListener(new EditButtonListener());
  }
 
  
  public void update(DictionaryInterface theDictionary) {
    DictionaryInterface.DictWord lastWord=theDictionary.getWord();

    if (theDictionary.getAction()==DictionaryInterface.Action.REMOVE &&
	lastWord.theWord==myWord.getText()) {
      myWord.setText("");
      myExpl.setText("");
    }

    if (lastWord.theWord==myWord.getText()) {
      myExpl.setText(lastWord.theExpl);
    }
  }


  public void display(String theWord, String theExpl) {
    myWord.setText(theWord);
    myExpl.setText(theExpl);
  }


  private ControllerInterface myController;
  public void setController(ControllerInterface theController) {
    myController=theController;
  }

  private class SearchButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      myController.search(myWord.getText());
    }
  }

  private class AddButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      myController.add(myWord.getText(), myExpl.getText());
    }
  }

  private class EditButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      myController.edit(myWord.getText(), myExpl.getText());
    }
  }

  
}
