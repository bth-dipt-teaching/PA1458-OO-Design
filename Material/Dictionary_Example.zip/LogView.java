
public class LogView implements DictObserver, DictionaryView
{

  public void update(DictionaryInterface theDictionary) {
    Dictionary.Action lastAction=theDictionary.getAction();
    Dictionary.DictWord lastWord=theDictionary.getWord();
    Log.log(""+lastAction+lastWord.theWord+lastWord.theExpl);
  }

  public void setController(ControllerInterface theController) {
    // Do nothing, will not send any data
  }
}

