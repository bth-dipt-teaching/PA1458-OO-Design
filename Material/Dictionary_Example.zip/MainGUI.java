import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MainGUI extends JFrame
{
  JPanel pane=new JPanel();

  public MainGUI() {
    super("Dictionary");
    setBounds(100,100,800,600);
    Container con=this.getContentPane();
    con.add(pane);
    pane.setLayout(new FlowLayout());
  }

  public void addView(JPanel theView) {
    pane.add(theView);
  }

  public void start() {
    setVisible(true);
  }
}
