import java.util.*;

public interface DictionaryInterface
{
  // Only for Controller
  public void addWord(String theWord, String theExpl);
  public void deleteWord(String theWord);
  public void editWord(String theWord, String theExpl);

  // Controller and Views
  public DictWord getWord(String theWord);
  public DictWord getWord();
  public Vector<DictWord> getWords();

  public class DictWord {
    public DictWord() {}   
    public DictWord(String w, String e) {
      theWord=w;
      theExpl=e;
    }
    
    String theWord;
    String theExpl;
  }

  public enum Action {NONE, ADD, REMOVE, EDIT}
  
  public Action getAction();
  public void addObserver(DictObserver theObserver);
    
}
