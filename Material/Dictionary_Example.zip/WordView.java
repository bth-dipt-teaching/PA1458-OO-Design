import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class WordView extends JPanel implements DictObserver, DictionaryView
{
  private JList myList = new JList();
  private JButton mySearch = new JButton("Search");
  
  public WordView() {
    setBorder(BorderFactory.createTitledBorder("Word List View"));
    this.setLayout(new BorderLayout());
    myList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
    myList.setLayoutOrientation(JList.VERTICAL);
    myList.setVisibleRowCount(-1);
    JScrollPane scrollPane = new JScrollPane(myList);
    scrollPane.setPreferredSize(new Dimension(100, 400));
    this.add("Center", scrollPane);
    this.add("South", mySearch);

    mySearch.addActionListener(new SearchButtonListener());
  }
 
  
  public void update(DictionaryInterface theDictionary) {
    if (theDictionary.getAction()==Dictionary.Action.ADD ||
	theDictionary.getAction()==Dictionary.Action.EDIT ||
	theDictionary.getAction()==Dictionary.Action.REMOVE) {
      getWords(theDictionary);
    }
  }

  public void getWords(DictionaryInterface theDictionary) {
    Vector<Dictionary.DictWord> dw=theDictionary.getWords();
    DefaultListModel lst=new DefaultListModel();
    
    Enumeration<Dictionary.DictWord> e=dw.elements();
    while(e.hasMoreElements()) {
      Dictionary.DictWord d=(Dictionary.DictWord) e.nextElement();
      lst.addElement(d.theWord);      
    }

    myList.setModel(lst);
    Log.log("WordView: Populated List");
  }


  private ControllerInterface myController;
  public void setController(ControllerInterface theController) {
    myController=theController;
  }


  private class SearchButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      myController.search(myList.getSelectedValue().toString());
    }
  }

}
